package manager;

import java.util.HashMap;
import java.util.Scanner;

public class ContactManagementSystem {
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        HashMap<String, String> contacts = new HashMap<>();

		        while (true) {
		            System.out.println("\nContact Management System");
		            System.out.println("1. Add Contact");
		            System.out.println("2. View Contacts");
		            System.out.println("3. Edit Contact");
		            System.out.println("4. Delete Contact");
		            System.out.println("5. Exit");
		            System.out.print("Enter your choice: ");
		            int choice = scanner.nextInt();
		            scanner.nextLine(); // Consume newline

		            switch (choice) {
		                case 1:
		                    System.out.print("Enter contact name: ");
		                    String name = scanner.nextLine();
		                    System.out.print("Enter phone number: ");
		                    String phoneNumber = scanner.nextLine();
		                    contacts.put(name, phoneNumber);
		                    System.out.println("Contact added successfully!");
		                    break;
		                case 2:
		                    System.out.println("Contacts:");
		                    for (String contactName : contacts.keySet()) {
		                        System.out.println(contactName + ": " + contacts.get(contactName));
		                    }
		                    break;
		                case 3:
		                    System.out.print("Enter contact name to edit: ");
		                    String editName = scanner.nextLine();
		                    if (contacts.containsKey(editName)) {
		                        System.out.print("Enter new phone number: ");
		                        String newPhoneNumber = scanner.nextLine();
		                        contacts.put(editName, newPhoneNumber);
		                        System.out.println("Contact updated successfully!");
		                    } else {
		                        System.out.println("Contact not found.");
		                    }
		                    break;
		                case 4:
		                    System.out.print("Enter contact name to delete: ");
		                    String deleteName = scanner.nextLine();
		                    if (contacts.containsKey(deleteName)) {
		                        contacts.remove(deleteName);
		                        System.out.println("Contact deleted successfully!");
		                    } else {
		                        System.out.println("Contact not found.");
		                    }
		                    break;
		                case 5:
		                    System.out.println("Exiting Contact Management System. Goodbye!");
		                    System.exit(0);
		                default:
		                    System.out.println("Invalid choice. Please select a valid option.");
		            }
		        }
		    }
		

	}


